/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.exoplayer.hls;

import android.util.SparseArray;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.DataReader;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.ParsableByteArray;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.SeekMap;
import androidx.media3.extractor.TrackOutput;
import java.io.EOFException;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Applies HLS SAMPLE-AES identity decryption to media samples before they reach SampleQueue. */
final class SampleAesExtractorOutput implements ExtractorOutput {

  private final ExtractorOutput wrappedOutput;
  private final byte[] key;
  private final byte[] iv;
  private final SparseArray<TrackOutput> trackOutputs;

  public SampleAesExtractorOutput(ExtractorOutput wrappedOutput, byte[] key, byte[] iv) {
    this.wrappedOutput = wrappedOutput;
    this.key = key;
    this.iv = iv;
    this.trackOutputs = new SparseArray<>();
  }

  @Override
  public TrackOutput track(int id, @C.TrackType int type) {
    @Nullable TrackOutput trackOutput = trackOutputs.get(id);
    if (trackOutput == null) {
      trackOutput =
          new SampleAesTrackOutput(wrappedOutput.track(id, type), type, key, iv);
      trackOutputs.put(id, trackOutput);
    }
    return trackOutput;
  }

  @Override
  public void endTracks() {
    wrappedOutput.endTracks();
  }

  @Override
  public void seekMap(SeekMap seekMap) {
    wrappedOutput.seekMap(seekMap);
  }

  private static final class SampleAesTrackOutput implements TrackOutput {

    private static final int INITIAL_PENDING_DATA_SIZE = 32 * 1024;
    private static final int AES_BLOCK_SIZE = 16;
    private static final int AVC_NAL_TYPE_NON_IDR = 1;
    private static final int AVC_NAL_TYPE_IDR = 5;

    private final TrackOutput wrappedOutput;
    private final @C.TrackType int trackType;
    private final byte[] key;
    private final byte[] iv;

    private byte[] pendingData;
    private int pendingLength;
    @Nullable private String sampleMimeType;

    public SampleAesTrackOutput(
        TrackOutput wrappedOutput, @C.TrackType int trackType, byte[] key, byte[] iv) {
      this.wrappedOutput = wrappedOutput;
      this.trackType = trackType;
      this.key = key;
      this.iv = iv;
      this.pendingData = new byte[INITIAL_PENDING_DATA_SIZE];
    }

    @Override
    public void durationUs(long durationUs) {
      wrappedOutput.durationUs(durationUs);
    }

    @Override
    public void format(Format format) {
      sampleMimeType = format.sampleMimeType;
      wrappedOutput.format(format);
    }

    @Override
    public int sampleData(
        DataReader input,
        int length,
        boolean allowEndOfInput,
        @SampleDataPart int sampleDataPart)
        throws IOException {
      ensurePendingCapacity(length);
      int bytesRead = input.read(pendingData, pendingLength, length);
      if (bytesRead == C.RESULT_END_OF_INPUT) {
        if (allowEndOfInput) {
          return C.RESULT_END_OF_INPUT;
        }
        throw new EOFException();
      }
      pendingLength += bytesRead;
      return bytesRead;
    }

    @Override
    public void sampleData(
        ParsableByteArray data, int length, @SampleDataPart int sampleDataPart) {
      ensurePendingCapacity(length);
      data.readBytes(pendingData, pendingLength, length);
      pendingLength += length;
    }

    @Override
    public void sampleMetadata(
        long timeUs,
        @C.BufferFlags int flags,
        int size,
        int offset,
        @Nullable CryptoData cryptoData) {
      int bytesReferencedByMetadata = size + offset;
      if (bytesReferencedByMetadata > pendingLength) {
        flushPendingWithoutDecrypting();
        wrappedOutput.sampleMetadata(timeUs, flags, size, offset, cryptoData);
        return;
      }

      int sampleStart = pendingLength - bytesReferencedByMetadata;
      if (sampleStart > 0) {
        discardPendingBytes(sampleStart);
      }

      byte[] sampleData = Arrays.copyOf(pendingData, size);
      if (shouldDecryptAvc()) {
        decryptAvcSample(sampleData, key, iv);
      } else if (shouldDecryptAac()) {
        decryptAacSample(sampleData, key, iv);
      }

      wrappedOutput.sampleData(new ParsableByteArray(sampleData), sampleData.length);
      wrappedOutput.sampleMetadata(timeUs, flags, sampleData.length, /* offset= */ 0, cryptoData);

      if (offset > 0) {
        System.arraycopy(pendingData, size, pendingData, 0, offset);
      }
      pendingLength = offset;
    }

    private boolean shouldDecryptAvc() {
      return trackType == C.TRACK_TYPE_VIDEO && MimeTypes.VIDEO_H264.equals(sampleMimeType);
    }

    private boolean shouldDecryptAac() {
      return trackType == C.TRACK_TYPE_AUDIO && MimeTypes.AUDIO_AAC.equals(sampleMimeType);
    }

    private void ensurePendingCapacity(int additionalLength) {
      int requiredLength = pendingLength + additionalLength;
      if (requiredLength <= pendingData.length) {
        return;
      }
      pendingData = Arrays.copyOf(pendingData, Math.max(requiredLength, pendingData.length * 2));
    }

    private void discardPendingBytes(int length) {
      int remainingLength = pendingLength - length;
      if (remainingLength > 0) {
        System.arraycopy(pendingData, length, pendingData, 0, remainingLength);
      }
      pendingLength = remainingLength;
    }

    private void flushPendingWithoutDecrypting() {
      if (pendingLength == 0) {
        return;
      }
      byte[] data = Arrays.copyOf(pendingData, pendingLength);
      wrappedOutput.sampleData(new ParsableByteArray(data), data.length);
      pendingLength = 0;
    }

    private static void decryptAacSample(byte[] sample, byte[] key, byte[] iv) {
      if (sample.length <= AES_BLOCK_SIZE) {
        return;
      }
      int encryptedLength = ((sample.length - AES_BLOCK_SIZE) / AES_BLOCK_SIZE) * AES_BLOCK_SIZE;
      if (encryptedLength == 0) {
        return;
      }
      byte[] encryptedData =
          Arrays.copyOfRange(sample, AES_BLOCK_SIZE, AES_BLOCK_SIZE + encryptedLength);
      byte[] decryptedData = decryptAesCbc(encryptedData, key, iv);
      System.arraycopy(decryptedData, 0, sample, AES_BLOCK_SIZE, decryptedData.length);
    }

    private static void decryptAvcSample(byte[] sample, byte[] key, byte[] iv) {
      int nalStartCodeOffset = findStartCode(sample, /* offset= */ 0);
      while (nalStartCodeOffset != C.INDEX_UNSET) {
        int nalStartOffset = nalStartCodeOffset + startCodeLength(sample, nalStartCodeOffset);
        int nextNalStartCodeOffset = findStartCode(sample, nalStartOffset);
        int nalEndOffset =
            nextNalStartCodeOffset == C.INDEX_UNSET ? sample.length : nextNalStartCodeOffset;
        if (nalStartOffset < nalEndOffset) {
          int nalUnitType = sample[nalStartOffset] & 0x1F;
          if ((nalUnitType == AVC_NAL_TYPE_NON_IDR || nalUnitType == AVC_NAL_TYPE_IDR)
              && nalEndOffset - nalStartOffset > 48) {
            decryptAvcNal(sample, nalStartOffset, nalEndOffset, key, iv);
          }
        }
        nalStartCodeOffset = nextNalStartCodeOffset;
      }
    }

    private static void decryptAvcNal(
        byte[] sample, int nalStartOffset, int nalEndOffset, byte[] key, byte[] iv) {
      int encryptedLength = 0;
      for (int offset = nalStartOffset + 32; offset < nalEndOffset - AES_BLOCK_SIZE; offset += 160) {
        encryptedLength += AES_BLOCK_SIZE;
      }
      if (encryptedLength == 0) {
        return;
      }

      byte[] encryptedData = new byte[encryptedLength];
      int encryptedDataOffset = 0;
      for (int offset = nalStartOffset + 32; offset < nalEndOffset - AES_BLOCK_SIZE; offset += 160) {
        System.arraycopy(sample, offset, encryptedData, encryptedDataOffset, AES_BLOCK_SIZE);
        encryptedDataOffset += AES_BLOCK_SIZE;
      }

      byte[] decryptedData = decryptAesCbc(encryptedData, key, iv);
      int decryptedDataOffset = 0;
      for (int offset = nalStartOffset + 32; offset < nalEndOffset - AES_BLOCK_SIZE; offset += 160) {
        System.arraycopy(decryptedData, decryptedDataOffset, sample, offset, AES_BLOCK_SIZE);
        decryptedDataOffset += AES_BLOCK_SIZE;
      }
    }

    private static byte[] decryptAesCbc(byte[] encryptedData, byte[] key, byte[] iv) {
      try {
        Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return cipher.doFinal(encryptedData);
      } catch (GeneralSecurityException e) {
        throw new IllegalStateException("Failed to decrypt HLS SAMPLE-AES sample", e);
      }
    }

    private static int findStartCode(byte[] data, int offset) {
      for (int i = offset; i <= data.length - 3; i++) {
        if (data[i] == 0 && data[i + 1] == 0) {
          if (data[i + 2] == 1) {
            return i;
          }
          if (i <= data.length - 4 && data[i + 2] == 0 && data[i + 3] == 1) {
            return i;
          }
        }
      }
      return C.INDEX_UNSET;
    }

    private static int startCodeLength(byte[] data, int startCodeOffset) {
      return data[startCodeOffset + 2] == 1 ? 3 : 4;
    }
  }
}
